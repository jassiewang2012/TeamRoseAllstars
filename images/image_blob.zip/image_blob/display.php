<?php
	$id=$_GET['id'];
	echo "<b>IMAGE:</b> <br><img src='createimgsource.php?image_id=".$id."' />";		
	//echo "divcontents";
?>
