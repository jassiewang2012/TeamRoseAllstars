<?php
  $host='localhost';
  //Change the user,password and database variables as desired
  $user='YOUR_DB_USERNAME';
  $pass='YOUR_DB_PASSWORD';
  $dbname='YOUR_DB_NAME';
  $link=mysql_connect($host,$user,$pass) or die(mysql_error());
  $db=mysql_select_db($dbname) or die(mysql_error());
?>